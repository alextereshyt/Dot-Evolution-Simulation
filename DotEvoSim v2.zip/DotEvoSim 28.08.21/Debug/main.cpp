#define _CRT_SECURE_NO_WARNINGS
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <time.h>
#include <string.h>
#include <windows.h>
#include <vector>


using namespace sf;
const int size1 = 50;
const int size2 = 50;
bool check(int matrix[][size2][4], int p1, int p2) {
	if (p1 >= 0 && p2 >= 0 && matrix[p1][p2][0] != -1 && p1 < size1 && p2 < size2)return 0;
	return 1;
}

void display(int matrix[][size2][4], int colors[][3], RenderWindow& window, int wheel, int x, int y, int res, Event event) {


	if (event.type == Event::Closed) {
		window.close();
		std::terminate();
	}




	window.clear(Color(209, 204, 199, 0));
	int mashtab = ((res / 100) * 2) + wheel;
	int size = wheel + (res / 100);
	for (int i = 0; i < size1; i++) {
		for (int j = 0; j < size2; j++) {
			CircleShape circle(size + 0.f);

			if (matrix[i][j][0] == -1) {

				circle.setFillColor(Color(0, 0, 0));
				circle.move((mashtab * i) + x, (mashtab * j) + y);
				window.draw(circle);
			}

			else if (matrix[i][j][0] > 0) {
				if (matrix[i][j][1] != 0) {
					if (matrix[i][j][1] == 1) {
						circle.setFillColor(Color(colors[1][0], colors[1][1], colors[1][2]));
						circle.move((mashtab * i) + x, (mashtab * j) + y);
						window.draw(circle);

					}

					else
					{

						circle.setFillColor(Color(colors[matrix[i][j][1] + 1][0], colors[matrix[i][j][1] + 1][1], colors[matrix[i][j][1] + 1][2])); // ����������� ��� ���� 
						circle.move((mashtab * i) + x, (mashtab * j) + y);
						window.draw(circle);
					}


				}
			}
			else if (matrix[i][j][3] > 0) {

				circle.setFillColor(Color(207 - (matrix[i][j][3] + 10), 202 - (matrix[i][j][3] + 10), 196 - (matrix[i][j][3] + 10)));
				circle.move((mashtab * i) + x, (mashtab * j) + y);
				window.draw(circle);

			}


			else {

				circle.setFillColor(Color(207, 202, 196));
				circle.move((mashtab * i) + x, (mashtab * j) + y);
				window.draw(circle);
			}


		}
	}
	//Sleep(10);
}


void displayLand(int matrix[][size2][4], int size1, int size2) {
	system("CLS");

	for (int i = 0; i < size1; i++) {
		for (int j = 0; j < size2; j++) {
			if (matrix[i][j][3] > 0) {
				{ if (matrix[i][j][3] - 10 > 0)std::cout << (matrix[i][j][3]); else std::cout << (matrix[i][j][3]) << ' '; }
			}
			else { std::cout << " "; }

		}
		std::cout << std::endl;
	}

}
int main()
{
	//inizial
	srand(time(0));
	int strange[10000];
	for (int s = 0; s < 1000; s++)
		strange[s] = 0;
	
	int matrix[size1][size2][4];
	int counts = 2;
	int tempcount = 0;
	int c = 0;
	int r1, r2;
	int temps;
	int temp;
	int tempchar = 0;
	int Fresources = 100;
	int proevo = 3;
	int REtemp = 0;
	int utemp = 1;
	int utemp1 = 1;
	int atemp;
	int colors[10000][3];
	int Slife;

	int Srange;
	int Smutation = 3000;
	int SGen = 1000;
	int wheel = 0;
	int x = 0, y = 0;
	int wtime = 0;
	int fre = 0;
	int soundMode = 0;
	float cameraMovementSpeed = 30;
	int maxPop;
	int res;
	char texttemp1[100];
	char texttemp2[100];
	int temptxt;
	int size;
	int mashtab;
	int tmp1;


	//sound.setLoop(true);
	std::cout << "Evolution of spicies simulation by Alex Tereshchuk" << std::endl;
	int setPco, setMode;
	std::cout << "Mode (1 - simulation without any conditions , 2 - wall and isolation , 3 - random conditions ): ";
	std::cin >> setMode;
	std::cout << "Debug pco(1): ";
	std::cin >> setPco;
	std::cout << "Debug srange(10): ";
	std::cin >> Srange;
	std::cout << "Cells life time(3): ";
	std::cin >> Slife;
	std::cout << "Max count of population(700): ";
	std::cin >> maxPop;
	std::cout << "Display resolution(700): ";
	std::cin >> res;
	std::cout << "Enable sound (1 - yes , 0 - no): ";
	std::cin >> soundMode;

	//sound
	sf::SoundBuffer buffer;
	sf::SoundBuffer buffer1;
	sf::SoundBuffer music;
	sf::Sound sound;
	sf::Sound sound1;
	sf::Sound music1;
	if (soundMode) {
		if (!music.loadFromFile("music.ogg"))
			std::cout << "Missing soundfile\n";

		if (!buffer.loadFromFile("sound.wav"))
			std::cout << "Missing soundfile\n";

		if (!buffer1.loadFromFile("sound1.wav"))
			std::cout << "Missing soundfile\n";

		sound.setBuffer(buffer);
		music1.setBuffer(music);
		sound1.setBuffer(buffer1);
		music1.setLoop(true);

	}
	//start
	for (int i = 0; i < size1; i++)
		for (int j = 0; j < size2; j++) {
			matrix[i][j][0] = 0;
			matrix[i][j][1] = 0;
			matrix[i][j][2] = 0;
			matrix[i][j][3] = 0;
		}

	//mode 3
	int Rgo = 0;
	if (setMode == 3) {
		while (Rgo == 0) {
			for (int timegen = 0; timegen < 6; timegen++) {
				for (int i = 0; i < size1; i++)
					for (int j = 0; j < size2; j++) {
						if (rand() % SGen == 0) {

							for (int p1 = -1; p1 < 2; p1++)
								for (int p2 = -1; p2 < 2; p2++)
								{
									if (check(matrix, i + p1, j + p2) == 0) {
										matrix[i + p1][j + p2][3] = rand() % 50;
									}
								}
							//reload
							for (int i = 0; i < size1; i++) {
								for (int j = 0; j < size2; j++) {
									if (matrix[i][j][3] > 0) {
										for (int p1 = -1; p1 < 2; p1++)
											for (int p2 = -1; p2 < 2; p2++)
											{
												if (i + p1 < 0 || j + p2 < 0);
												else if (matrix[i + p1][j + p2][3] > 0 && matrix[i + p1][j + p2][3] == matrix[i][j][3])c++;

											}

										r1 = (rand() % 3 - 1);
										r2 = (rand() % 3 - 1);

										if (c >= 3) {
											while (check(matrix, i + r1, j + r2) && matrix[i + r1][j + r2][3] == 0) {
												r1 = (rand() % 3 - 1);
												r2 = (rand() % 3 - 1);

											}


											matrix[i + r1][j + r2][3] = matrix[i][j][3];

											c = 0;
										}




									}
								}

							}


						}

					}




			}

			displayLand(matrix, size1, size2);
			std::cout << "Do you want to use this pattern(1 - yes , 0 - no): ";
			std::cin >> Rgo;
			if (Rgo == 0)  for (int i = 0; i < size1; i++)
				for (int j = 0; j < size2; j++) {
					matrix[i][j][3] = 0;
				}
		}

	}
	//music start
	music1.play();



	//first gen

	for (int i = 0; i < size1; i++)
		for (int j = 0; j < size2; j++) {
			temp = 0;
			for (int p1 = -1; p1 < 2; p1++)
				for (int p2 = -1; p2 < 2; p2++)
				{
					if (check(matrix, i + p1, j + p2) == 0 && matrix[i + p1][j + p2][3] <= 1) {
						temp++;
						matrix[i + p1][j + p2][0] = 500;
						matrix[i + p1][j + p2][1] = 1;
						matrix[i + p1][j + p2][2] = 1;

					}

				}
			if (temp >= 3) { i = size1 - 1; j = size2 - 1; }

		}
	colors[1][0] = rand() % 255;
	colors[1][1] = rand() % 255;
	colors[1][2] = rand() % 255;
	colors[2][0] = rand() % 255;
	colors[2][1] = rand() % 255;
	colors[2][2] = rand() % 255;
	if (setMode == 2) {
		for (int i = 0; i < size1; i++)
			matrix[i][25][0] = -1;
		matrix[9][25][0] = 0;
		matrix[10][25][0] = 0;
		matrix[11][25][0] = 0;
	}
	RectangleShape back(sf::Vector2f(res+610, res));
	back.setFillColor(sf::Color(224, 221, 218));
	back.move(res, 0);
	RenderWindow window(VideoMode(res + 610, res), "Evolution Simulation");
	//Drawing

	//text 
	window.setFramerateLimit(60);

	Font font;
	font.loadFromFile("prstart.ttf");

	while (window.isOpen())
	{


		Event event;
		while (window.pollEvent(event))
		{

			if (event.type == Event::Closed) {
				window.close();
				return 0;
			}

			if (Keyboard::isKeyPressed(Keyboard::O))
			{
				for (int i = 0; i < size1; i++)
					for (int j = 0; j < size2; j++) {
						matrix[i][j][0] = 0;
						matrix[i][j][1] = 0;
						matrix[i][j][2] = 0;
						matrix[i][j][3] = 0;
					}
				for (int i = 0; i < size1; i++)
					for (int j = 0; j < size2; j++) {
						temp = 0;
						for (int p1 = -1; p1 < 2; p1++)
							for (int p2 = -1; p2 < 2; p2++)
							{
								if (check(matrix, i + p1, j + p2) == 0 && matrix[i + p1][j + p2][3] <= 1) {
									temp++;
									matrix[i + p1][j + p2][0] = 500;
									matrix[i + p1][j + p2][1] = 1;
									matrix[i + p1][j + p2][2] = 1;

								}

							}
						if (temp >= 3) { i = size1 - 1; j = size2 - 1; }

					}
			}
			if (Keyboard::isKeyPressed(Keyboard::P))
			{
				wtime--;

			}
			if (Keyboard::isKeyPressed(Keyboard::C))
			{
				while (Keyboard::isKeyPressed(Keyboard::V) == 0) {


				}

			}


			else if (Keyboard::isKeyPressed(Keyboard::F))
			{
				x = 0;
				y = 0;
				wheel = 0;
			}

			if (event.type == sf::Event::MouseWheelMoved)
			{

				wheel = wheel + event.mouseWheel.delta;
				if (wheel > 0)wheel = 0;
				if (wheel < -5)wheel = -5;
			}
		}
		//camera move
		if (Keyboard::isKeyPressed(Keyboard::W))
		{
			y = y + cameraMovementSpeed;
		}
		else if (Keyboard::isKeyPressed(Keyboard::S))
		{
			y = y - cameraMovementSpeed;
		}
		else if (Keyboard::isKeyPressed(Keyboard::A))
		{
			x = x + cameraMovementSpeed;
		}
		else if (Keyboard::isKeyPressed(Keyboard::D))
		{
			x = x - cameraMovementSpeed;
		}
		display(matrix, colors, window, wheel, x, y, res, event);


		//wall settings
		if (setMode == 2) {
			if (wtime % 300 == 0) {
				matrix[9][25][0] = -1;
				matrix[10][25][0] = -1;
				matrix[11][25][0] = -1;


			}
			if (wtime % 600 == 0) {
				matrix[9][25][0] = 0;
				matrix[10][25][0] = 0;
				matrix[11][25][0] = 0;

			}
		}
		//display all data

		strcpy(texttemp1, "Year: ");
		_itoa(wtime, texttemp2, 10);
		strcat(texttemp1, texttemp2);
		Text text(texttemp1, font, 20);
		text.setFillColor(Color::Black);
		text.setPosition(res + 10, 0);


		strcpy(texttemp1, "Count of spicies: ");
		_itoa(counts, texttemp2, 10);
		strcat(texttemp1, texttemp2);
		Text text2(texttemp1, font, 20);
		text2.setFillColor(Color::Black);
		text2.setPosition(res + 10, 30);


		strcpy(texttemp1, "Strange: ");
		for (int ti = counts - 10; ti < counts; ti++) {
			if (ti >= 0) {
				if (ti == 0);
				else if (ti == 1) {
					_itoa(1, texttemp2, 10);
					strcat(texttemp1, texttemp2);
				}
				else if (strange[ti - 2] >= 0)
					if (strange[ti - 2] > 9) {
						_itoa(strange[ti - 2], texttemp2, 10);
						strcat(texttemp1, texttemp2);


					}
					else {
						_itoa(strange[ti - 2], texttemp2, 10);
						strcat(texttemp1, texttemp2);


					}
				strcat(texttemp1, " ");
			}
		}


		_itoa(counts, texttemp2, 10);
		strcat(texttemp1, texttemp2);
		Text text3(texttemp1, font, 20);
		text3.setFillColor(Color::Black);
		text3.setPosition(res + 10, 60);

		/*strcpy(texttemp1, "Name:    ");
		Text text4(texttemp1, font, 20);
		text4.setFillColor(Color::Black);
		text4.setPosition(res, 90);
		size = (res / 100);
		mashtab = ((res / 100) * 2) ;

		CircleShape circle2(size + 0.f);

		for (int ti = counts - 10; ti < counts; ti++) {
			if (ti >= 0) {

				CircleShape circle(size + 0.f);
				circle.setFillColor(Color(colors[1][ti], colors[2][ti], colors[3][ti]));
				circle.move((199 + res + mashtab * ti+(ti*30)), 95);
				window.draw(circle);

			}
		}*/



		//population resources
		temp = 0;
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j][0] > 0) {
					temp++;
				}


			}



		strcpy(texttemp1, "Count of living cells: ");
		_itoa(temp, texttemp2, 10);
		strcat(texttemp1, texttemp2);
		Text text4(texttemp1, font, 20);

		if (temp >= maxPop) {
			proevo = setPco + 1; Slife = 3; text4.setFillColor(Color::Red);
		}
		else if (temp > maxPop - 50 && temp < maxPop) {
			text4.setFillColor(Color(148, 35, 35));
		}
		else {
			proevo = setPco; text4.setFillColor(Color::Black);
		}
		text4.setPosition(res + 10, 90);

		//reload
		for (int i = 0; i < size1; i++) {
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j][0] > 0 && wtime - matrix[i][j][0] == Slife) {
					matrix[i][j][0] = 0; matrix[i][j][1] = 0; matrix[i][j][2] = 0;
				}
				else if (matrix[i][j][0] > 0) {
					for (int p1 = -1; p1 < 2; p1++)
						for (int p2 = -1; p2 < 2; p2++)
						{

							if (check(matrix, p1 + i, p2 + j) == 0 && matrix[i + p1][j + p2][0] > 0 && matrix[i + p1][j + p2][1] == matrix[i][j][1]) {
								c++;
							}
						}

					r1 = (rand() % 3 - 1);
					r2 = (rand() % 3 - 1);

					if (rand() % 3 == 0)
						sound.setPitch(2.2f);
					if (rand() % 3 == 1)
						sound.setPitch(5.2f);
					if (rand() % 3 == 2)
						sound.setPitch(7.2f);

					if (c >= 3) {

						if (matrix[i + r1][j + r2][0] != -1 && matrix[i + r1][j + r2][0] == 0 && check(matrix, i + r1, j + r2) == 0) {
							if (matrix[i + r1][j + r2][3] == 0) {
								matrix[i + r1][j + r2][0] = wtime;
								matrix[i + r1][j + r2][1] = matrix[i][j][1];
								matrix[i + r1][j + r2][2] = matrix[i][j][2];
								if (rand() % 4 == 0)
									sound.play();
							}
							else if (matrix[i][j][2] >= matrix[i + r1][j + r2][3] && matrix[i][j][2] <= matrix[i + r1][j + r2][3] + Srange) {
								matrix[i + r1][j + r2][0] = wtime;
								matrix[i + r1][j + r2][1] = matrix[i][j][1];
								matrix[i + r1][j + r2][2] = matrix[i][j][2];
								if (rand() % 4 == 0)
									sound.play();

							}
						}
						c = 0;
					}
					else if (c <= proevo) {
						matrix[i][j][0] = 0;
						matrix[i][j][1] = 0;
					}



				}
			}

		}
		// mutation
		for (int i = 0; i < size1; i++)
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j][0] > 0)
					if ((rand() % Smutation == 0 && matrix[i][j + 1][0] != -1 && matrix[i + 1][j + 1][0] != -1)) {
						temp = rand() % 15 - 7;
						if (matrix[i][j][3] == 0 || matrix[i][j][2] + temp >= matrix[i + r1][j + r2][3] && matrix[i][j][2] + temp <= matrix[i + r1][j + r2][3] + Srange) {

							if (matrix[i][j][2] + temp > 0) {

								matrix[i][j + 1][2] = matrix[i][j][2] + temp;
								matrix[i][j][2] = matrix[i][j][2] + temp;
								matrix[i + 1][j][2] = matrix[i][j][2] + temp;

							}
							else {
								matrix[i][j][2] = 1; matrix[i][j + 1][2] = 1;
								matrix[i - 1][j][2] = 1;
							}

							matrix[i][j][0] = wtime + 2;
							matrix[i][j][1] = counts + 1;
							matrix[i][j + 1][0] = wtime + 2;
							matrix[i][j + 1][1] = counts + 1;
							matrix[i + 1][j + 1][0] = wtime + 2;
							matrix[i + 1][j + 1][1] = counts + 1;
							colors[counts + 1][0] = rand() % 255;
							colors[counts + 1][1] = rand() % 255;
							colors[counts + 1][2] = rand() % 255;

							counts++;
							strange[tempcount] = matrix[i][j][2];
							tempcount++;
							sound1.play();


						}
					}

			}
		// who is stranger
		for (int i = 0; i < size1; i++) {
			for (int j = 0; j < size2; j++) {
				if (matrix[i][j][0] > 0) {
					for (int p1 = -1; p1 < 2; p1++)
						for (int p2 = -1; p2 < 2; p2++)
						{
							if (matrix[i + p1][j + p2][0] > 0)
								if (matrix[i + p1][j + p2][1] != matrix[i][j][1] && matrix[i + p1][j + p2][2] < matrix[i][j][2] && p1 != 0 && p2 != 0) {
									matrix[i + p1][j + p2][1] = 0; matrix[i + p1][j + p2][0] = 0; matrix[i + p1][j + p2][2] = 0;

								}

						}

				}
			}
		}




		window.draw(back);
		window.draw(text);
		window.draw(text2);
		window.draw(text3);
		window.draw(text4);
		window.display();
		wtime++;
	}

	return 0;

}
